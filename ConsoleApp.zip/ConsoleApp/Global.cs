﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class Global
    {
        public static string StoreName = "monca03090";

        public static string Token = "LMXhZSCbryck8EOjTS93";

        public static string CreditCardNumber = "";

        public static string CreditCardExpiryDate = "";
    }


    
}
