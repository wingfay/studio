﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
   public class Win32Test
   {



      public delegate bool EnumWindowsProc(IntPtr hWnd, int lParam);

      [DllImport("USER32.DLL")]
      public static extern bool EnumWindows(EnumWindowsProc enumFunc, int lParam);


      [DllImport("user32.dll", CharSet = CharSet.Unicode)]
      private static extern int GetWindowTextLength(IntPtr hWnd);

      [DllImport("user32.dll", SetLastError = true)]
      public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

      [DllImport("user32.dll")]
      [return: MarshalAs(UnmanagedType.Bool)]
      public static extern bool EnumChildWindows(IntPtr hwndParent, EnumWindowsProc lpEnumFunc, int lParam);

      [DllImport("USER32.DLL")]
      public static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

      [DllImport("User32.dll", EntryPoint = "GetWindowText")]
      public static extern int GetWindowText(IntPtr hwnd, StringBuilder lpString, int cch);

      [DllImport("User32.dll", EntryPoint = "GetWindowTextA")]
      public static extern int GetWindowTextA(IntPtr hwnd, out StringBuilder lpString, int cch);

      [DllImport("user32.dll", EntryPoint = "SendMessageA")]
      private static extern int SendMessage(IntPtr hwnd, int wMsg, int wParam, StringBuilder lParam);

      [DllImport("user32.dll", EntryPoint = "SendMessage", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
      public static extern bool SendMessage(IntPtr hWnd, uint Msg, int wParam, StringBuilder lParam);

      [DllImport("user32.dll", SetLastError = true)]
      public static extern IntPtr SendMessage(int hWnd, int Msg, int wparam, int lparam);

      const int WM_GETTEXT = 0x000D;
      const int WM_GETTEXTLENGTH = 0x000E;

      public static string GetControlText(IntPtr hWnd)
      {

         // Get the size of the string required to hold the window title (including trailing null.) 
         Int32 titleSize = SendMessage((int)hWnd, WM_GETTEXTLENGTH, 0, 0).ToInt32();

         // If titleSize is 0, there is no title so return an empty string (or null)
         if (titleSize == 0)
            return String.Empty;

         StringBuilder title = new StringBuilder(titleSize + 1);

         SendMessage(hWnd, (int)WM_GETTEXT, title.Capacity, title);

         return title.ToString();
      }


      public static string GetWindowClass(IntPtr hWnd)
      {
         int length = 255;
         StringBuilder builder = new StringBuilder(length);
         GetClassName(hWnd, builder, length + 1);
         return builder.ToString();
      }
      /// <summary> Get the text for the window pointed to by hWnd </summary>
      public static string GetWindowText(IntPtr hWnd)
      {
         int size = GetWindowTextLength(hWnd);
         if (size > 0)
         {
            var builder = new StringBuilder(size + 1);
            GetWindowText(hWnd, builder, builder.Capacity);
            return builder.ToString();
         }

         return String.Empty;
      }


      public static string GetRichTextBoxText(IntPtr hWnd)
      {
         int size = GetWindowTextLength(hWnd);
         if (size > 0)
         {
            var builder = new StringBuilder(size + 1);
            GetWindowText(hWnd, builder, builder.Capacity);
            return builder.ToString();
         }

         return String.Empty;
      }



      public static IntPtr Find_Word_FULLPAGEUIHOST()
		{
         //RichTextBoxHelper richTextBoxHelper = new RichTextBoxHelper();

         IntPtr FULLPAGEUIHOST = IntPtr.Zero;


         int i = 0;
         bool found= EnumWindows(delegate (IntPtr wnd, int _)
         {

            string ClassName = GetWindowClass(wnd);

            if (ClassName == "OpusApp")
            {
               bool Result = EnumChildWindows(wnd, (wnd1, __) =>
               {

                  string apppName = GetWindowClass(wnd1);

                  if (apppName.ToUpper() == "FULLPAGEUIHOST")
                  {
                     FULLPAGEUIHOST = wnd1;

							//Console.WriteLine($"{++i} apppName:{apppName}");
							return false;
                     //EnumChildWindows(wnd1, (wnd2, ___) =>
                     //{

                     //   if (apppName.ToUpper() == "RICHEDIT60W")
                     //   {
                     //      string cap = GetWindowText(wnd1);

                     //      if (string.IsNullOrEmpty(cap))
                     //      {
                     //         cap = GetControlText(wnd1);
                     //      }

                     //      Console.WriteLine($"{++i} apppName:{apppName} Value:{cap}");
                     //   }
                     //   else if (apppName.ToUpper() == "NetUIHWND")
                     //   {
                     //      var icon = Win32.IconHelper.GetAppIcon(wnd1);

                     //      if (icon != null)
                     //      {
                     //         Console.WriteLine($"{++i} apppName:{apppName} ICON:1");
                     //      }
                     //      else
                     //      {
                     //         Console.WriteLine($"{++i} apppName:{apppName}");
                     //      }
                     //   }

                     //   else
                     //   {
                     //      Console.WriteLine($"{++i} apppName:{apppName}");
                     //   }

                     //   return true;
                     //}, 0);

                  }




                  return true;

               }, 0);


       
              // Console.WriteLine($"{++i} result:{Result}");

               if (FULLPAGEUIHOST != IntPtr.Zero)
               {
                  string apppName = GetWindowClass(FULLPAGEUIHOST);

                 //  Console.WriteLine($"{++i} apppName:{apppName}");

                  return false;
               }
            }

            return true;

         }, 0);

         return FULLPAGEUIHOST;


      }

      public static void GetWindow()
      {
         Console.WriteLine($"{DateTime.Now}");

         IntPtr wnd = Find_Word_FULLPAGEUIHOST();

         int i = 0;

         if (wnd != IntPtr.Zero)
			{
            string apppName = GetWindowClass(wnd);
            Console.WriteLine($"root apppName:{apppName}");

            EnumChildWindows(wnd, (wnd1, ___) =>
				{

               apppName = GetWindowClass(wnd1);

               if (apppName.ToUpper() == "RICHEDIT60W")
					{
						string cap = GetWindowText(wnd1);

						if (string.IsNullOrEmpty(cap))
						{
							cap = GetControlText(wnd1);
						}

						Console.WriteLine($"{++i} apppName:{apppName} Value:{cap}");
					}
					else if (apppName.ToUpper() == "NetUIHWND")
					{
						var icon = Win32.IconHelper.GetAppIcon(wnd1);

						if (icon != null)
						{
							Console.WriteLine($"{++i} apppName:{apppName} ICON:1");
						}
						else
						{
							Console.WriteLine($"{++i} apppName:{apppName}");
						}
					}

					else
					{
						Console.WriteLine($"{++i} apppName:{apppName}");
					}

					return true;
				}, 0);
			}
			else
			{

			}

      }




     
   }

   public static class RichEditMessages
   {
      public const int WM_CONTEXTMENU = 123;
      public const int WM_UNICHAR = 265;
      public const int WM_PRINTCLIENT = 792;
      public const int EM_GETLIMITTEXT = 1061;
      public const int EM_POSFROMCHAR = 1062;
      public const int EM_CHARFROMPOS = 1063;
      public const int EM_SCROLLCARET = 1073;
      public const int EM_CANPASTE = 1074;
      public const int EM_DISPLAYBAND = 1075;
      public const int EM_EXGETSEL = 1076;
      public const int EM_EXLIMITTEXT = 1077;
      public const int EM_EXLINEFROMCHAR = 1078;
      public const int EM_EXSETSEL = 1079;
      public const int EM_FINDTEXT = 1080;
      public const int EM_FORMATRANGE = 1081;
      public const int EM_GETCHARFORMAT = 1082;
      public const int EM_GETEVENTMASK = 1083;
      public const int EM_GETOLEINTERFACE = 1084;
      public const int EM_GETPARAFORMAT = 1085;
      public const int EM_GETSELTEXT = 1086;
      public const int EM_HIDESELECTION = 1087;
      public const int EM_PASTESPECIAL = 1088;
      public const int EM_REQUESTRESIZE = 1089;
      public const int EM_SELECTIONTYPE = 1090;
      public const int EM_SETBKGNDCOLOR = 1091;
      public const int EM_SETCHARFORMAT = 1092;
      public const int EM_SETEVENTMASK = 1093;
      public const int EM_SETOLECALLBACK = 1094;
      public const int EM_SETPARAFORMAT = 1095;
      public const int EM_SETTARGETDEVICE = 1096;
      public const int EM_STREAMIN = 1097;
      public const int EM_STREAMOUT = 1098;
      public const int EM_GETTEXTRANGE = 1099;
      public const int EM_FINDWORDBREAK = 1100;
      public const int EM_SETOPTIONS = 1101;
      public const int EM_GETOPTIONS = 1102;
      public const int EM_FINDTEXTEX = 1103;
      public const int EM_GETWORDBREAKPROCEX = 1104;
      public const int EM_SETWORDBREAKPROCEX = 1105;
      public const int EM_SETUNDOLIMIT = 1106;
      public const int EM_REDO = 1108;
      public const int EM_CANREDO = 1109;
      public const int EM_GETUNDONAME = 1110;
      public const int EM_GETREDONAME = 1111;
      public const int EM_STOPGROUPTYPING = 1112;
      public const int EM_SETTEXTMODE = 1113;
      public const int EM_GETTEXTMODE = 1114;
   }


 //  public class RichTextBoxHelper
	//{
 //     public string ReadRTF(IntPtr handle)
 //     {
 //        string result = String.Empty;
 //        using (MemoryStream stream = new MemoryStream())
 //        {
 //           EDITSTREAM editStream = new EDITSTREAM();
 //           editStream.pfnCallback = new EditStreamCallback(EditStreamProc);
 //           editStream.dwCookie = stream;

 //           SendMessage(new HandleRef(this,handle), EM_STREAMIN, SF_RTF, ref editStream);

 //           stream.Seek(0, SeekOrigin.Begin);
 //           using (StreamReader reader = new StreamReader(stream))
 //           {
 //              result = reader.ReadToEnd();
 //           }
 //        }
 //        return result;
 //     }

 //     private int EditStreamProc(MemoryStream dwCookie, IntPtr pbBuff, int cb, out int pcb)
 //     {
 //        pcb = cb;
 //        byte[] buffer = new byte[cb];
 //        Marshal.Copy(pbBuff, buffer, 0, cb);
 //        dwCookie.Write(buffer, 0, cb);
 //        return 0;
 //     }
 //     public delegate int EditStreamCallback(IntPtr dwCookie, IntPtr buf, int cb, out int transferred);


 //    // private delegate int EditStreamCallback(MemoryStream dwCookie, IntPtr pbBuff, int cb, out int pcb);


 //     [StructLayout(LayoutKind.Sequential)]
 //     public class GETTEXTLENGTHEX
 //     {                               // Taken from richedit.h:
 //        public uint flags;          // Flags (see GTL_XXX defines)              
 //        public uint codepage;       // Code page for translation (CP_ACP for default, 1200 for Unicode)                         
 //     }

 //     [StructLayout(LayoutKind.Sequential)]
 //     public class EDITSTREAM
 //     {
 //        public IntPtr dwCookie = IntPtr.Zero;
 //        public int dwError = 0;
 //        public EditStreamCallback pfnCallback = null;
 //     }


 //     [StructLayout(LayoutKind.Sequential)]
 //     public class EDITSTREAM64
 //     {
 //        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
 //        public byte[] contents = new byte[20];
 //     }

 //     //[StructLayout(LayoutKind.Sequential)]
 //     //private class EDITSTREAM
 //     //{
 //     //   public MemoryStream dwCookie;
 //     //   public int dwError;
 //     //   public EditStreamCallback pfnCallback;
 //     //}

 //     [DllImport("user32.dll", CharSet = CharSet.Auto)]
 //     private static extern IntPtr SendMessage(HandleRef hwnd, uint msg, uint wParam, ref EDITSTREAM lParam);

 //     public const int WM_USER = 0x0400;
 //     public const int EM_STREAMIN = (WM_USER + 73);
 //     public const int EM_STREAMOUT = WM_USER + 74;
 //     public const int SF_RTF = 2;


 //     private unsafe EDITSTREAM64 ConvertToEDITSTREAM64(EDITSTREAM es)
 //     {
 //        EDITSTREAM64 es64 = new EDITSTREAM64();

 //        fixed (byte* es64p = &es64.contents[0])
 //        {
 //           byte* bp;
 //           long l;

 //           /*
 //           l = (long) es.dwCookie;
 //           bp = (byte *) &l;
 //           for (int i=0; i < sizeof(long); i++) {
 //               es64.contents[i] = bp[i];
 //           }*/
 //           *((long*)es64p) = (long)es.dwCookie;
 //           /*
 //           int il = es.dwError;
 //           bp = (byte *) &il;
 //           for (int i=0; i < sizeof(int); i++) {
 //               es64.contents[i+8] = bp[i];
 //           }*/
 //           *((int*)(es64p + 8)) = es.dwError;

 //           l = (long)Marshal.GetFunctionPointerForDelegate(es.pfnCallback);
 //           bp = (byte*)&l;
 //           for (int i = 0; i < sizeof(long); i++)
 //           {
 //              es64.contents[i + 12] = bp[i];
 //           }
 //           //*((long *)(es64p + 12)) = (long) Marshal.GetFunctionPointerForDelegate(es.pfnCallback);
 //        }

 //        return es64;
 //     }


 //  }
}
